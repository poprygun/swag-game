package io.pivotal.microsamples.api;

import io.pivotal.microsamples.model.Guess;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2017-04-27T14:21:03.339-04:00")

@Controller
public class RandomizeApiController implements RandomizeApi {

    @Override
    public ResponseEntity<List<Guess>> allGuesses() {
        List<Guess> guesses = new ArrayList<>();

        Guess guess = new Guess();
        guess.setGuessed(true);
        guess.setGuessedPhrase("Guess Phrase");
        guess.setResponsePhrase("Guess what?");

        Guess guess2 = new Guess();
        guess2.setGuessed(false);
        guess2.setGuessedPhrase("Did not Guess Phrase");
        guess2.setResponsePhrase("Random Riddler?");

        guesses.add(guess);
        guesses.add(guess2);

        ResponseEntity<List<Guess>> response = new ResponseEntity<List<Guess>>(guesses, HttpStatus.OK);
        return response;
    }

    @Override
    public ResponseEntity<String> health() {
        String response = "{\"health\" : \"I am alive!!!!\"}";
        ResponseEntity<String> responseEntity = new ResponseEntity<>(response, HttpStatus.OK);
        return responseEntity;
    }
}
